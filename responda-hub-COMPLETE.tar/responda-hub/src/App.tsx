import Hub from './pages/Hub'
import './styles/globals.css'

function App() {
  return <Hub />
}

export default App
